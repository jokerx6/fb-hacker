#!/usr/bin/env python

from distutils.core import setup

setup(name='FBHT',
      version='3.0',
      description='FBHT',
      author='Chino Ogawa',
      url='https://github.com/chinoogawa/fbht',
	  console=['main.py']      
     )
