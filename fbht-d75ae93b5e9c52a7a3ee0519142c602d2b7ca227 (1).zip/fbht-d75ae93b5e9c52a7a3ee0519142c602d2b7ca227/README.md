FBHT
====

Facebook Hacking Tool

Python  - -version 2.7.3 (Windows/Linux)

IMPORTS
====
  - Selenium
  - Matplotlib-1.2.1
  - Networkx-1.8.1
  - Numpy-1.7.1
  - Pygraphviz-1.1
  - Simplejson-3.3.0
  - Mechanize-0.2.5
  - Other: gephi-0.8.2-beta (Graphs software)
  
Recomendation:
====
  - Use setuptools for the dependencies

S.O
====
  - Working on Windows 7 64/32 bits
  - Working on Kali Linux (Yeah, sucks) but probably works on the others (deprecated - read below)

Usage
====
  - python main.py 


Thanks
====
Thanks to @alepernin for the path handling in linux version.

Set variable path handling according to OS; should work on either Windows, Mac or Linux systems.

Tested on Windows 7, Kali Linux, Debian 7 (Wheezy).

